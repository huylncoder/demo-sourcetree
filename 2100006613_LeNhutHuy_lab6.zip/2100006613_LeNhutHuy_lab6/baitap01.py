import tkinter as tk
from tkinter import ttk

# Create the main window
root = tk.Tk()
root.title("Frame Recorder")
root.geometry("600x300")
root.configure(bg="green")

# Add a large title label in the center
title_label = ttk.Label(root, text="Frame Recorder", font=("Arial", 24), background="lightpink")
title_label.pack(pady=20)

# Create a frame to hold the FPS input and label
fps_frame = ttk.Frame(root, padding="10", relief="solid")
fps_frame.pack(pady=10)

fps_label = ttk.Label(fps_frame, text="create an ", background="lightpink")
fps_label.pack(side="left", padx=5)

fps_entry = ttk.Entry(fps_frame)
fps_entry.pack(side="left", padx=5)

fps_unit_label = ttk.Label(fps_frame, text="fps video", background="lightpink")
fps_unit_label.pack(side="left", padx=5)

# Create a frame to hold the buttons
button_frame = ttk.Frame(root, padding="10", relief="solid")
button_frame.pack(pady=10)

pause_button = ttk.Button(button_frame, text="Pause")
pause_button.pack(side="left", padx=10)

start_button = ttk.Button(button_frame, text="Start")
start_button.pack(side="left", padx=10)

end_button = ttk.Button(button_frame, text="End")
end_button.pack(side="left", padx=10)

# Add a status label at the bottom
status_label = ttk.Label(root, text="Recording Paused", font=("Arial", 14), background="lightpink")
status_label.pack(pady=20)

# Run the application
root.mainloop()
