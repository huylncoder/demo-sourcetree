import tkinter as tk
from tkinter import ttk

# Create the main window
root = tk.Tk()
root.title("AtarBals AntiVirus")
root.geometry("800x500")
root.configure(bg="white")

# Create a frame for the sidebar
sidebar_frame = ttk.Frame(root, width=200, relief="solid")
sidebar_frame.pack(side="left", fill="y")

# Sidebar labels
sections = ["Status", "Updates", "Settings", "Share Feedback", "Buy Premium", "Help"]
for section in sections:
    label = ttk.Label(sidebar_frame, text=section, padding="10", background="lightblue")
    label.pack(fill="x")

# Scan Now button with background color
scan_now_button = ttk.Button(sidebar_frame, text="Scan Now", style="scan.TButton")
scan_now_button.pack(pady=20)

# Create a style for the button background color
style = ttk.Style()
style.configure("scan.TButton", background="green")  # Change to your desired color

# Create a frame for the main content
main_content_frame = ttk.Frame(root, padding="10", relief="solid")
main_content_frame.pack(side="right", expand=True, fill="both")

# Title label
title_label = ttk.Label(main_content_frame, text="Scan", font=("Arial", 24))
title_label.pack(pady=10)

# Subtitle label
subtitle_label = ttk.Label(main_content_frame, text="Premium will be free forever. You just need to click button.", font=("Arial", 10))
subtitle_label.pack(pady=5)

# Buttons for different actions with background color using the defined style
actions = ["Quick Scan", "Web Protection", "Quarantine", "Full Scan", "Simple Update"]
for action in actions:
    button = ttk.Button(main_content_frame, text=action, style="scan.TButton")  # Apply the defined style
    button.pack(pady=5)

# Status label at the bottom
status_label = ttk.Label(main_content_frame, text="Get Premium to Enable: {Web Protection}, {Full Scan}, {Simple Update}", font=("Arial", 10))
status_label.pack(side="bottom", pady=10)

# Run the application
root.mainloop()
